# Slope Session - iOS 10 Speech Recognition Tutorial For Beginners In Swift 3 #

[![speechrecog.png](https://bitbucket.org/repo/9L4rax/images/3170429024-speechrecog.png)](https://www.youtube.com/watch?v=2gs5QTRC8Yk&index=11&list=PLpZBns8dFbgz7BWwgq1Hkaazu0hLg9xHg)

*Click the image above to watch this Slope Session on YouTube.*
### Description ###

This is the source code accompanying the iOS 10 Speech Recognition Tutorial For Beginners In Swift 3 Slope Session. It utilises the new Speech framework in iOS 10. 👍

**Note:** *Be sure to drag in '**test.m4a**' from the project folder and into Xcode so that the app can successfully find and use it.*

![resources.png](https://bitbucket.org/repo/9L4rax/images/3647781691-resources.png)

Happy coding!

![170.png](https://bitbucket.org/repo/9LeroX/images/1216100977-170.png)

**Caleb Stultz**